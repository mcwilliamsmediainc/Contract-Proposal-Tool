"""
crawl.py — Rank Tracker Crawler
Fetches Organic Desktop, Organic Mobile, Local Pack, and Local Finder
rankings from SerpApi and saves each snapshot to SQLite.

Schedule this via Replit's built-in cron (every Sunday night or as needed).
"""

import os
import sqlite3
import json
import time
import logging
from datetime import date
from serpapi import GoogleSearch  # pip install google-search-results

# ─── CONFIG ──────────────────────────────────────────────────────────────────

SERPAPI_KEY = os.environ.get("SERPAPI_KEY", "YOUR_SERPAPI_KEY_HERE")
DB_PATH = os.environ.get("DB_PATH", "data/rankings.db")

# Target business — the domain or business name to look for in results
TARGET_DOMAIN = os.environ.get("TARGET_DOMAIN", "yourbusiness.com")
TARGET_BUSINESS_NAME = os.environ.get("TARGET_BUSINESS_NAME", "Your Business Name")

# How many organic results deep to scan (SerpApi returns up to 100)
MAX_ORGANIC_DEPTH = 20

# Seconds to wait between API calls (avoids hammering the API)
CALL_DELAY = 0.5

# ─── LOGGING ─────────────────────────────────────────────────────────────────

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler("crawl.log"),
        logging.StreamHandler()
    ]
)
log = logging.getLogger(__name__)

# ─── DATABASE ────────────────────────────────────────────────────────────────

def init_db(db_path: str) -> sqlite3.Connection:
    """Create tables if they don't exist."""
    os.makedirs(os.path.dirname(db_path) if os.path.dirname(db_path) else ".", exist_ok=True)
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS keywords (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            keyword     TEXT NOT NULL,
            location    TEXT NOT NULL,
            lat         REAL,
            lng         REAL,
            active      INTEGER DEFAULT 1,
            created_at  TEXT DEFAULT (date('now')),
            UNIQUE(keyword, location)
        );

        CREATE TABLE IF NOT EXISTS snapshots (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            keyword_id      INTEGER NOT NULL REFERENCES keywords(id),
            snap_date       TEXT NOT NULL,
            organic_desktop INTEGER,
            organic_mobile  INTEGER,
            local_pack      INTEGER,
            local_finder    INTEGER,
            raw_desktop     TEXT,
            raw_mobile      TEXT,
            raw_local_pack  TEXT,
            raw_local_finder TEXT,
            created_at      TEXT DEFAULT (datetime('now')),
            UNIQUE(keyword_id, snap_date)
        );

        CREATE INDEX IF NOT EXISTS idx_snapshots_date ON snapshots(snap_date);
        CREATE INDEX IF NOT EXISTS idx_snapshots_keyword ON snapshots(keyword_id);
    """)
    conn.commit()
    return conn


def upsert_keyword(conn: sqlite3.Connection, keyword: str, location: str,
                   lat: float = None, lng: float = None) -> int:
    """Insert keyword+location if not exists, return its id."""
    conn.execute(
        "INSERT OR IGNORE INTO keywords (keyword, location, lat, lng) VALUES (?, ?, ?, ?)",
        (keyword, location, lat, lng)
    )
    conn.commit()
    row = conn.execute(
        "SELECT id FROM keywords WHERE keyword=? AND location=?", (keyword, location)
    ).fetchone()
    return row["id"]


def save_snapshot(conn: sqlite3.Connection, keyword_id: int, snap_date: str,
                  ranks: dict, raws: dict):
    """Insert or replace a snapshot row."""
    conn.execute("""
        INSERT INTO snapshots
            (keyword_id, snap_date,
             organic_desktop, organic_mobile, local_pack, local_finder,
             raw_desktop, raw_mobile, raw_local_pack, raw_local_finder)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(keyword_id, snap_date) DO UPDATE SET
            organic_desktop  = excluded.organic_desktop,
            organic_mobile   = excluded.organic_mobile,
            local_pack       = excluded.local_pack,
            local_finder     = excluded.local_finder,
            raw_desktop      = excluded.raw_desktop,
            raw_mobile       = excluded.raw_mobile,
            raw_local_pack   = excluded.raw_local_pack,
            raw_local_finder = excluded.raw_local_finder,
            created_at       = datetime('now')
    """, (
        keyword_id, snap_date,
        ranks.get("organic_desktop"), ranks.get("organic_mobile"),
        ranks.get("local_pack"), ranks.get("local_finder"),
        json.dumps(raws.get("desktop", {})),
        json.dumps(raws.get("mobile", {})),
        json.dumps(raws.get("local_pack", {})),
        json.dumps(raws.get("local_finder", {})),
    ))
    conn.commit()

# ─── SERPAPI HELPERS ─────────────────────────────────────────────────────────

def find_organic_rank(results: list, target_domain: str) -> int | None:
    """Return 1-based position of target domain in organic results, or None."""
    for i, r in enumerate(results):
        link = r.get("link", "") or ""
        displayed = r.get("displayed_link", "") or ""
        if target_domain.lower() in link.lower() or target_domain.lower() in displayed.lower():
            return i + 1
    return None


def find_local_pack_rank(local_results: list, target_name: str) -> int | None:
    """Return 1-based position in the local 3-pack, or None."""
    for i, r in enumerate(local_results):
        title = r.get("title", "") or ""
        if target_name.lower() in title.lower():
            return i + 1
    return None


def fetch_organic(keyword: str, location: str, device: str) -> tuple[int | None, dict]:
    """Fetch organic ranking for desktop or mobile."""
    params = {
        "engine": "google",
        "q": keyword,
        "location": location,
        "device": device,
        "num": MAX_ORGANIC_DEPTH,
        "api_key": SERPAPI_KEY,
        "no_cache": True,
    }
    try:
        search = GoogleSearch(params)
        results = search.get_dict()
        organic = results.get("organic_results", [])
        rank = find_organic_rank(organic, TARGET_DOMAIN)
        return rank, results
    except Exception as e:
        log.error(f"Organic {device} fetch failed for '{keyword}': {e}")
        return None, {}


def fetch_local_pack(keyword: str, location: str) -> tuple[int | None, dict]:
    """Fetch Local Pack (3-pack) ranking."""
    params = {
        "engine": "google",
        "q": keyword,
        "location": location,
        "api_key": SERPAPI_KEY,
        "no_cache": True,
    }
    try:
        search = GoogleSearch(params)
        results = search.get_dict()
        local = results.get("local_results", [])
        rank = find_local_pack_rank(local, TARGET_BUSINESS_NAME)
        return rank, results
    except Exception as e:
        log.error(f"Local pack fetch failed for '{keyword}': {e}")
        return None, {}


def fetch_local_finder(keyword: str, lat: float, lng: float) -> tuple[int | None, dict]:
    """Fetch Local Finder (Google Maps) ranking."""
    if not lat or not lng:
        return None, {}
    params = {
        "engine": "google_maps",
        "q": keyword,
        "ll": f"@{lat},{lng},14z",
        "type": "search",
        "api_key": SERPAPI_KEY,
        "no_cache": True,
    }
    try:
        search = GoogleSearch(params)
        results = search.get_dict()
        local = results.get("local_results", [])
        rank = find_local_pack_rank(local, TARGET_BUSINESS_NAME)
        return rank, results
    except Exception as e:
        log.error(f"Local finder fetch failed for '{keyword}': {e}")
        return None, {}

# ─── MAIN CRAWL LOOP ─────────────────────────────────────────────────────────

def crawl_all(keywords: list[dict], snap_date: str = None):
    """
    keywords: list of dicts with keys: keyword, location, lat (opt), lng (opt)
    snap_date: ISO date string, defaults to today
    """
    if not snap_date:
        snap_date = date.today().isoformat()

    conn = init_db(DB_PATH)
    total = len(keywords)
    log.info(f"Starting crawl for {total} keywords on {snap_date}")

    for i, kw_obj in enumerate(keywords):
        keyword  = kw_obj["keyword"]
        location = kw_obj["location"]
        lat      = kw_obj.get("lat")
        lng      = kw_obj.get("lng")

        log.info(f"[{i+1}/{total}] {keyword} @ {location}")

        keyword_id = upsert_keyword(conn, keyword, location, lat, lng)

        # 1. Organic Desktop
        od_rank, od_raw = fetch_organic(keyword, location, "desktop")
        time.sleep(CALL_DELAY)

        # 2. Organic Mobile
        om_rank, om_raw = fetch_organic(keyword, location, "mobile")
        time.sleep(CALL_DELAY)

        # 3. Local Pack
        lp_rank, lp_raw = fetch_local_pack(keyword, location)
        time.sleep(CALL_DELAY)

        # 4. Local Finder (Google Maps)
        lf_rank, lf_raw = fetch_local_finder(keyword, lat, lng)
        time.sleep(CALL_DELAY)

        ranks = {
            "organic_desktop": od_rank,
            "organic_mobile":  om_rank,
            "local_pack":      lp_rank,
            "local_finder":    lf_rank,
        }
        raws = {
            "desktop":      od_raw,
            "mobile":       om_raw,
            "local_pack":   lp_raw,
            "local_finder": lf_raw,
        }

        save_snapshot(conn, keyword_id, snap_date, ranks, raws)
        log.info(f"  → OD:{od_rank} OM:{om_rank} LP:{lp_rank} LF:{lf_rank}")

    conn.close()
    log.info(f"Crawl complete. {total} keywords saved to {DB_PATH}")


# ─── ENTRY POINT ─────────────────────────────────────────────────────────────

if __name__ == "__main__":
    # Load keywords from keywords.json (edit this file to add/remove keywords)
    import sys
    keywords_file = sys.argv[1] if len(sys.argv) > 1 else "keywords.json"

    if not os.path.exists(keywords_file):
        log.error(f"Keywords file not found: {keywords_file}")
        log.info("Create a keywords.json file — see keywords.example.json for format")
        sys.exit(1)

    with open(keywords_file) as f:
        keywords = json.load(f)

    crawl_all(keywords)
