"""
api.py — Rank Tracker API
Serves ranking data from SQLite to the frontend dashboard.
Run with: python api.py
"""

import os
import sqlite3
import json
from flask import Flask, jsonify, request
from flask_cors import CORS
from datetime import date, timedelta

app = Flask(__name__)
CORS(app)  # Allow frontend to call this API

DB_PATH = os.environ.get("DB_PATH", "data/rankings.db")

# ─── DB HELPER ───────────────────────────────────────────────────────────────

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

# ─── ROUTES ──────────────────────────────────────────────────────────────────

@app.route("/api/dates")
def get_dates():
    """Return all available snapshot dates, newest first."""
    conn = get_db()
    rows = conn.execute(
        "SELECT DISTINCT snap_date FROM snapshots ORDER BY snap_date DESC"
    ).fetchall()
    conn.close()
    return jsonify([r["snap_date"] for r in rows])


@app.route("/api/locations")
def get_locations():
    """Return all distinct locations in the keywords table."""
    conn = get_db()
    rows = conn.execute(
        "SELECT DISTINCT location FROM keywords WHERE active=1 ORDER BY location"
    ).fetchall()
    conn.close()
    return jsonify([r["location"] for r in rows])


@app.route("/api/rankings")
def get_rankings():
    """
    Return rankings table comparing two snapshots.
    Query params:
      date1     - current date  (default: latest)
      date2     - previous date (default: second latest)
      location  - filter by location (optional)
    """
    conn = get_db()

    # Get available dates
    all_dates = [r["snap_date"] for r in conn.execute(
        "SELECT DISTINCT snap_date FROM snapshots ORDER BY snap_date DESC"
    ).fetchall()]

    if not all_dates:
        return jsonify({"error": "No snapshot data yet. Run crawl.py first."}), 404

    date1 = request.args.get("date1", all_dates[0])
    date2 = request.args.get("date2", all_dates[1] if len(all_dates) > 1 else None)
    location_filter = request.args.get("location")

    # Build keyword query
    kw_query = "SELECT id, keyword, location FROM keywords WHERE active=1"
    kw_params = []
    if location_filter:
        kw_query += " AND location=?"
        kw_params.append(location_filter)
    kw_query += " ORDER BY keyword"

    keywords = conn.execute(kw_query, kw_params).fetchall()

    rows = []
    for kw in keywords:
        # Fetch snapshot for date1
        s1 = conn.execute(
            "SELECT * FROM snapshots WHERE keyword_id=? AND snap_date=?",
            (kw["id"], date1)
        ).fetchone()

        # Fetch snapshot for date2
        s2 = conn.execute(
            "SELECT * FROM snapshots WHERE keyword_id=? AND snap_date=?",
            (kw["id"], date2)
        ).fetchone() if date2 else None

        def rank_val(snap, col):
            return snap[col] if snap and snap[col] is not None else None

        def compute_change(cur, prev):
            """
            Returns change info:
            - None if no previous data
            - "new" if appeared for first time
            - "lost" if disappeared
            - integer delta if both present (positive = improved)
            """
            if cur is None and prev is None:
                return None
            if cur is not None and prev is None:
                return "new"
            if cur is None and prev is not None:
                return "lost"
            delta = prev - cur  # positive = moved UP (smaller rank = better)
            return delta

        rows.append({
            "keyword":  kw["keyword"],
            "location": kw["location"],
            "organic_desktop": {
                "rank":   rank_val(s1, "organic_desktop"),
                "change": compute_change(rank_val(s1, "organic_desktop"), rank_val(s2, "organic_desktop"))
            },
            "organic_mobile": {
                "rank":   rank_val(s1, "organic_mobile"),
                "change": compute_change(rank_val(s1, "organic_mobile"), rank_val(s2, "organic_mobile"))
            },
            "local_pack": {
                "rank":   rank_val(s1, "local_pack"),
                "change": compute_change(rank_val(s1, "local_pack"), rank_val(s2, "local_pack"))
            },
            "local_finder": {
                "rank":   rank_val(s1, "local_finder"),
                "change": compute_change(rank_val(s1, "local_finder"), rank_val(s2, "local_finder"))
            },
        })

    conn.close()
    return jsonify({
        "date1":    date1,
        "date2":    date2,
        "location": location_filter,
        "rows":     rows,
    })


@app.route("/api/keyword/<int:keyword_id>/history")
def keyword_history(keyword_id):
    """Return full ranking history for a single keyword (for trend charts)."""
    conn = get_db()
    kw = conn.execute("SELECT * FROM keywords WHERE id=?", (keyword_id,)).fetchone()
    if not kw:
        return jsonify({"error": "Keyword not found"}), 404

    snaps = conn.execute(
        """SELECT snap_date, organic_desktop, organic_mobile, local_pack, local_finder
           FROM snapshots WHERE keyword_id=? ORDER BY snap_date ASC""",
        (keyword_id,)
    ).fetchall()
    conn.close()

    return jsonify({
        "keyword":  kw["keyword"],
        "location": kw["location"],
        "history":  [dict(s) for s in snaps],
    })


@app.route("/api/summary")
def get_summary():
    """Top-level stats for dashboard header cards."""
    conn = get_db()
    all_dates = [r["snap_date"] for r in conn.execute(
        "SELECT DISTINCT snap_date FROM snapshots ORDER BY snap_date DESC LIMIT 2"
    ).fetchall()]

    if not all_dates:
        return jsonify({"total_keywords": 0, "top3_count": 0, "improved": 0, "declined": 0})

    date1 = all_dates[0]
    date2 = all_dates[1] if len(all_dates) > 1 else None

    total_kw = conn.execute("SELECT COUNT(*) as c FROM keywords WHERE active=1").fetchone()["c"]

    # Count keywords ranking in top 3 organic desktop today
    top3 = conn.execute(
        """SELECT COUNT(*) as c FROM snapshots s
           JOIN keywords k ON k.id=s.keyword_id
           WHERE s.snap_date=? AND s.organic_desktop<=3 AND k.active=1""",
        (date1,)
    ).fetchone()["c"]

    improved = 0
    declined = 0
    if date2:
        snaps1 = {r["keyword_id"]: r for r in conn.execute(
            "SELECT * FROM snapshots WHERE snap_date=?", (date1,)).fetchall()}
        snaps2 = {r["keyword_id"]: r for r in conn.execute(
            "SELECT * FROM snapshots WHERE snap_date=?", (date2,)).fetchall()}
        for kid in snaps1:
            if kid in snaps2:
                r1 = snaps1[kid]["organic_desktop"]
                r2 = snaps2[kid]["organic_desktop"]
                if r1 and r2:
                    if r1 < r2: improved += 1
                    elif r1 > r2: declined += 1

    conn.close()
    return jsonify({
        "total_keywords": total_kw,
        "top3_count":     top3,
        "improved":       improved,
        "declined":       declined,
        "latest_date":    date1,
    })


@app.route("/api/keywords", methods=["GET"])
def list_keywords():
    conn = get_db()
    rows = conn.execute(
        "SELECT id, keyword, location, active, created_at FROM keywords ORDER BY keyword"
    ).fetchall()
    conn.close()
    return jsonify([dict(r) for r in rows])


@app.route("/api/keywords", methods=["POST"])
def add_keyword():
    data = request.get_json()
    keyword  = data.get("keyword", "").strip()
    location = data.get("location", "").strip()
    lat      = data.get("lat")
    lng      = data.get("lng")
    if not keyword or not location:
        return jsonify({"error": "keyword and location required"}), 400
    conn = get_db()
    try:
        conn.execute(
            "INSERT OR IGNORE INTO keywords (keyword, location, lat, lng) VALUES (?,?,?,?)",
            (keyword, location, lat, lng)
        )
        conn.commit()
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    finally:
        conn.close()
    return jsonify({"status": "ok"})


@app.route("/health")
def health():
    return jsonify({"status": "ok"})


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=False)
