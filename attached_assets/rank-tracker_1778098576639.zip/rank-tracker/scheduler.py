"""
scheduler.py — Run this as a separate Replit Always-On process
OR use Replit's built-in Cron Jobs feature to call crawl.py on a schedule.

Schedule options in Replit:
  - Go to Tools → Cron Jobs
  - Add a new job: python scripts/crawl.py
  - Set schedule: 0 2 * * 0  (every Sunday at 2am)
     or           0 2 * * *  (every day at 2am for daily tracking)

This file is a fallback if you want a long-running scheduler inside Replit.
"""

import schedule
import time
import subprocess
import logging
from datetime import datetime

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger(__name__)

def run_crawl():
    log.info(f"Starting scheduled crawl at {datetime.now().isoformat()}")
    result = subprocess.run(
        ["python", "scripts/crawl.py", "keywords.json"],
        capture_output=True, text=True
    )
    if result.returncode == 0:
        log.info("Crawl completed successfully")
    else:
        log.error(f"Crawl failed:\n{result.stderr}")

# ── Schedule config ───────────────────────────────────────────────────────────
# Weekly on Sundays at 2am
schedule.every().sunday.at("02:00").do(run_crawl)

# Uncomment for daily:
# schedule.every().day.at("02:00").do(run_crawl)

# Uncomment to test immediately on startup:
# run_crawl()

log.info("Scheduler started. Waiting for next run...")
while True:
    schedule.run_pending()
    time.sleep(60)
