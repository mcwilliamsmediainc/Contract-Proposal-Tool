"""
main.py — Single entry point for Replit
Serves the Flask API + the static frontend from one process.
Replit will run this automatically.
"""

import os
from flask import Flask, send_from_directory, jsonify
from flask_cors import CORS

# Import all API routes
import sys
sys.path.insert(0, os.path.dirname(__file__))

from api import app

# Serve the frontend at the root
@app.route("/")
def serve_index():
    return send_from_directory("frontend", "index.html")

@app.route("/<path:path>")
def serve_static(path):
    return send_from_directory("frontend", path)

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 3000))
    print(f"🚀 Rank Tracker running on port {port}")
    print(f"   Dashboard: http://localhost:{port}")
    print(f"   API:       http://localhost:{port}/api/rankings")
    app.run(host="0.0.0.0", port=port, debug=False)
