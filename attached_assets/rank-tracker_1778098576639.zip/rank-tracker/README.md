# Rank Tracker — Replit Setup Guide

A self-hosted Google rank tracker using SerpApi. Replicates BrightLocal's
Rankings Table with Organic Desktop, Organic Mobile, Local Pack, and Local Finder.

---

## Project Structure

```
rank-tracker/
├── main.py              ← Replit entry point (runs API + frontend)
├── api.py               ← Flask REST API
├── scheduler.py         ← Optional: long-running cron scheduler
├── requirements.txt     ← Python dependencies
├── keywords.json        ← YOUR KEYWORD LIST (edit this)
├── data/
│   └── rankings.db      ← SQLite database (auto-created)
├── scripts/
│   └── crawl.py         ← SerpApi fetcher script
└── frontend/
    └── index.html       ← Dashboard UI
```

---

## Step 1 — Create a Replit project

1. Go to [replit.com](https://replit.com) and create a new **Python** Repl
2. Name it `rank-tracker`
3. Upload all files from this project (or paste them in)

---

## Step 2 — Set environment variables

In Replit, go to **Tools → Secrets** and add:

| Secret Key          | Value                        |
|---------------------|------------------------------|
| `SERPAPI_KEY`       | Your SerpApi API key         |
| `TARGET_DOMAIN`     | yourdomain.com               |
| `TARGET_BUSINESS_NAME` | Your Business Name        |
| `DB_PATH`           | data/rankings.db             |

---

## Step 3 — Install dependencies

In the Replit Shell:
```bash
pip install -r requirements.txt
```

---

## Step 4 — Edit your keywords

Open `keywords.json` and add your keywords:

```json
[
  {
    "keyword": "BBQ Catering Tulsa",
    "location": "Tulsa, Oklahoma",
    "lat": 36.1540,
    "lng": -95.9928
  }
]
```

**Tips:**
- `location` must match a SerpApi location string exactly
- `lat`/`lng` are required for Local Finder (Google Maps) tracking
- Find lat/lng at maps.google.com — right-click any location

---

## Step 5 — Run your first crawl

In the Replit Shell:
```bash
python scripts/crawl.py keywords.json
```

This will:
1. Loop through every keyword
2. Make 4 SerpApi calls per keyword (Desktop, Mobile, Local Pack, Local Finder)
3. Save results to `data/rankings.db`
4. Print a log of each result

**Estimated time:** ~2 seconds per keyword (with rate limiting)
**API calls used:** 4 × number of keywords

---

## Step 6 — Start the dashboard

Click **Run** in Replit (or run `python main.py` in Shell).

Your dashboard will be live at your Replit URL:
`https://rank-tracker.YOUR-USERNAME.repl.co`

---

## Step 7 — Schedule weekly crawls

In Replit, go to **Tools → Cron Jobs** and create a new job:

| Field    | Value                        |
|----------|------------------------------|
| Command  | `python scripts/crawl.py keywords.json` |
| Schedule | `0 2 * * 0` (Sundays 2am)   |

For daily tracking: `0 2 * * *`

---

## Adding / Removing Keywords

**Option A — Edit keywords.json directly**
Add or remove entries, then run the crawl again.

**Option B — Use the dashboard**
Click "+ Add Keyword" in the UI. The keyword is saved to the database
immediately, and will be included in the next crawl.

---

## SerpApi Call Budget

| Keywords | Calls per run | Weekly  | Monthly (weekly runs) |
|----------|--------------|---------|----------------------|
| 50       | 200          | 200     | 800                  |
| 200      | 800          | 800     | 3,200                |
| 500      | 2,000        | 2,000   | 8,000                |

Check your SerpApi plan limits at [serpapi.com/manage-api-key](https://serpapi.com/manage-api-key)

---

## API Endpoints

| Endpoint                        | Description                        |
|---------------------------------|------------------------------------|
| `GET /api/rankings`             | Rankings table (main data)         |
| `GET /api/dates`                | Available snapshot dates           |
| `GET /api/locations`            | Available locations                |
| `GET /api/summary`              | Header stat cards                  |
| `GET /api/keyword/:id/history`  | Trend data for one keyword         |
| `POST /api/keywords`            | Add a new keyword                  |

---

## Troubleshooting

**"No snapshot data yet"** — Run `python scripts/crawl.py` first

**Rank shows None for Local Pack** — Business name in `TARGET_BUSINESS_NAME`
must match the name as it appears in Google Maps exactly

**SerpApi 401 error** — Check your `SERPAPI_KEY` secret in Replit

**Wrong rankings** — Verify `TARGET_DOMAIN` matches your actual domain
(e.g. `mybusiness.com` not `https://www.mybusiness.com`)
